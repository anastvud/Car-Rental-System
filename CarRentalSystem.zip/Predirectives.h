#ifndef MAIN_CPP_PREDIRECTIVES_H
#define MAIN_CPP_PREDIRECTIVES_H

#include <iostream>
#include <string>
#include <ctime>
#include <vector>
#include "di.hpp"
using namespace std;
namespace di = boost::di;

#endif //MAIN_CPP_PREDIRECTIVES_H